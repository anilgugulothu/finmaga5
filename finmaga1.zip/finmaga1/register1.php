<?php
	require 'dbconfig/config.php'
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Register form</title>
 
  <link rel="stylesheet" href="css/login1.css">
  
</head>
<body style="background:url(images/background.jpg);">
     
  <div id=main-wrapper>
  <center>
	<h2> Login Form</h2>
	<img src="images/avatar.jpg" class="avatar">
  </center>
  
 
   <form action="register1.php" method="POST" class="myform">
     
        <label>USERNAME:</label><br>
		<input name="username" type="text" name="name"  class="inputvalues" placeholder="username here" required><br><br>
        <label>PASSWORD:</label><br>
		<input name="passwrod" type="password" name="password" class="inputvalues" placeholder="password here" required><br><br>
		<label>CONFIRM PASSWORD:</label><br>
<input name="cpasswrod" type="password" name="password" class="inputvalues" placeholder="confirm your password" required><br><br>
		<input name="submit_btn" type="submit" id="signup-btn" value="SignUp"><br>
        <a href="sample.html"><input type="button" id="back-btn" value="Back"></a><br>
    </form>
	
	<?php
	if(isset($_POST['submit_btn']))
	{
		//echo '<script type="text/javascript"> alert("Sign Up button clicked") </script>';
		$username = $_POST['username'];
		$password = $_POST['password'];
		$cpassword = $_POST['cpassword'];
		if($password==$cpassword)
		{
			$query="select * from user WHERE username='$username'";
			
			$query_run= mysqli_query($con,$query);
			
			if(mysqli_num_rows($query_run)>0)
			{
				//there is already a user exist
	echo '<script type="text/javascript"> alert("User already exist!!! try new one") </script>';
			}
			else
			{
				$query="insert into user values('$username','$password')";
				$query_run = mysqli_query($con,$query);
				if($query_run)
				{
		echo '<script type="text/javascript"> alert("User Registered... Go to Login Page") </script>';			
				}
				else
				{
		echo '<script type="text/javascript"> alert("ERROR") </script>';			
				}
			}
		}
		else
		{
		echo '<script type="text/javascript"> alert("passwords do not matched") </script>';	
		}
	}
	?>
	
  </div>
</body>
</html>