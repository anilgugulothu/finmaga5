<?php
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>freshii meal box</title>
  <link rel="stylesheet" href="css/bootstrap.css">
  <!--including css files-->
  <link rel="stylesheet" href="css/login.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
  <!--link for font-->
</head>
<body  style="background:url(images/background.jpg);">
  <div class="container">
    <div class="col-xs-4" style="background-color:#009fff;">
      <img src="images/finmagaloginlogo.png" alt="" class="img-responsive">
    </div>
    <div class="col-xs-8" style="background-color:white;" >
    <form action="">
          <div class="form-group has-feedback">
            <input class="form-control" type="text" placeholder="Email Id" id="inputUserEmail">
            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
          </div>
          <div class="form-group has-feedback">
            <input  class="form-control" type="password" placeholder="password" id="inputPassword">
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div>
          <button type="submit">Login</button>
        </form>

    </div>

  </div>

  <script type="text/javascript" src="js/jqueryuncompressed.js"></script>
  <!--including jquery uncompressed files-->
  <script type="text/javascript" src="js/bootstrap.js"></script>
  <!--including javascriptfiles-->
</body>
</html>